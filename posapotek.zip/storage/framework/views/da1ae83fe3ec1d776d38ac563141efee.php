<?php
    $type = $type ?? config('captcha.default', 'image');
    $difficulty = $difficulty ?? config('captcha.difficulty', 'medium');
    $style = $style ?? config('captcha.style', 'default');
    $id = $id ?? 'captcha-' . uniqid();
?>

<div class="captcha-container captcha-style-<?php echo e($style); ?>" id="<?php echo e($id); ?>" data-type="<?php echo e($type); ?>" data-difficulty="<?php echo e($difficulty); ?>">
    <?php if($type === 'image'): ?>
        <?php echo $__env->make('captcha::types.image', ['id' => $id, 'difficulty' => $difficulty, 'style' => $style], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php elseif($type === 'math'): ?>
        <?php echo $__env->make('captcha::types.math', ['id' => $id, 'difficulty' => $difficulty, 'style' => $style], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php elseif($type === 'text'): ?>
        <?php echo $__env->make('captcha::types.text', ['id' => $id, 'difficulty' => $difficulty, 'style' => $style], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php elseif($type === 'slider'): ?>
        <?php echo $__env->make('captcha::types.slider', ['id' => $id, 'difficulty' => $difficulty, 'style' => $style], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div>
<?php if (! $__env->hasRenderedOnce('8052c6b8-c855-46b2-96ff-d8170bbe87df')): $__env->markAsRenderedOnce('8052c6b8-c855-46b2-96ff-d8170bbe87df'); ?>
    <?php $__env->startPush('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('vendor/captcha/css/captcha.css')); ?>">
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('vendor/captcha/js/captcha.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const captcha = new LaravelCaptcha('<?php echo e($id); ?>', {
            type: '<?php echo e($type); ?>',
            difficulty: '<?php echo e($difficulty); ?>',
            style: '<?php echo e($style); ?>'
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php /**PATH C:\xampp\htdocs\posapotek\vendor\dev-3bdulrahman\laravel-captcha\src/../resources/views/captcha.blade.php ENDPATH**/ ?>