<div class="captcha-image-wrapper">
    <div class="captcha-image-container">
        <img src="<?php echo e(route('captcha.image', ['type' => 'image', 'difficulty' => $difficulty])); ?>" 
             alt="Captcha Image" 
             class="captcha-image"
             id="<?php echo e($id); ?>-image">
        <button type="button" class="captcha-refresh" onclick="refreshCaptcha('<?php echo e($id); ?>')" title="<?php echo e(__('Refresh captcha')); ?>">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="23 4 23 10 17 10"></polyline>
                <polyline points="1 20 1 14 7 14"></polyline>
                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
            </svg>
        </button>
    </div>
    <div class="captcha-input-group">
        <label for="<?php echo e($id); ?>-input" class="captcha-label">
            <i class="fas fa-keyboard me-1"></i>
            <?php echo e(__('Enter the code above:')); ?>

        </label>
        <input type="text" 
               id="<?php echo e($id); ?>-input" 
               name="captcha" 
               class="captcha-input <?php $__errorArgs = ['captcha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               placeholder="<?php echo e(__('Enter captcha code')); ?>"
               autocomplete="off"
               required>
    </div>
</div><?php /**PATH C:\xampp\htdocs\posapotek\vendor\dev-3bdulrahman\laravel-captcha\src/../resources/views/types/image.blade.php ENDPATH**/ ?>